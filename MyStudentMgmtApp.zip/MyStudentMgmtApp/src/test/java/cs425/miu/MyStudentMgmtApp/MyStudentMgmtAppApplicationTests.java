package cs425.miu.MyStudentMgmtApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyStudentMgmtAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
